              Parallax S2 GUI Perl Source Code
        ___________________________________________

        Copyright (C) 2005-2015  Bueno Systems, Inc.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You can download a copy of the GNU General Public License here:

  http://www.gnu.org/licenses/gpl-2.0.html
  
No technical support for these files is being offered and none
will be given. Those using these files for any purpose are on
their own.
_______________________________________________________________

Installation Instructions:

S2.pl and Scribbler.pm should be installed in the project's root
directory. The other Scribbler-specific Perl modules should be
installed to a "Scribbler" subdirectory of the project's root
directory. The file "ToggleButton.pm" should be installed in the
Perl Tk library directory with the other Tk modules, usually
/perl/site/lib/Tk. Any other needed modules can be obtained via
ppm (for Active State's Perl) or through CPAN.

This bundle contains only those files which are not included with
the S2 GUI executable installation package. A complete source
installation will need those files as well.
