Most recent update: 7/24/2011

Hello fellow robot enthusiast.

This is a work in progress, but in general what you find here is:

S2 Workshop, Student Workbook
S2 Workshop, Instructors Guide
Certificates to give to winners of Competition 1
A variety of Scribbler 2 programs, usable by the "Program Maker"

For more information on the S2 robot and resources, be sure to go to:

http://www.parallax.com/go/s2

If you find this workshop and materials useful (or not) please let me know.  Also, be sure to check out the copyright notice included just behind the cover page of the Student Workbook.

Enjoy
Neil Rosenberg
Neil@vectorr.com
828-484-4444
