S2 Demo Code
7/2/2013
Stephanie Lindsay
Parallax Inc.

These very small demo programs are for the S2 Robot and the Scribbler Program Maker GUI v1.3.2 Please feel free to use and adapt them for any S2 use that you like.
 
Available from www.parallax.com/go/S2

***SPIRO DESIGNS***

All of the "...Spiro.scb" programs are variations on a theme: drive forward, then turn a bit, repeat. If you put a pen in the S2 pen port, the result will be a drawing of a flower-like or spirograph-like design.  These programs are fun for introducing math concepts of distance and angle of rotation.  Challenge your students to make a square, equilateral triangle, 10-point star, etc.
It is also a way to demonstrate various types of turning: center pivot with wheels going in opposite directions, or pivoting on a wheel by making one stay still and the other go forward or backward. Each variant of turning produces a different drawing result.  
For S2 drawing activities, an inexpensive piece of Melamine shower board and slim fine-point dry-erase pens are lots of fun.  With permanent markers such as Sharpies, we suggest using several thicknesses of butcher paper to keep the pen from bleeding through to the surface underneath. It is safest to try a "dry run" with a new program to make sure the robot stays within the bounds of the drawing surface before using it with the pen in place.

***SEE CIRCLE UH OH***

See-Circle-UhOh.scb makes the S2 drive in a circle. It uses its infrared object decectors to check for an obstacle in its path. If it sees an obstacle, it stops driving and says "Uh Oh!" until the obstacle is removed.  This program demonstrates sensor-based if-then decision making in an infinite loop.  